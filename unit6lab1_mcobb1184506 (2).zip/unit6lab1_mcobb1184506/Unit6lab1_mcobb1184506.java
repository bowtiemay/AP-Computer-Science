/*
 * This program prompts the user to enter integers in the range 1 to 50
 * and counts the occurrences of each integer. The program also prompts the 
 * user for the number of integers that will be entered.
 */
package unit6lab1_mcobb1184506;

import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author marie
 */
public class Unit6lab1_mcobb1184506 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        //aquire a list length
        System.out.print("Enter the number of integers that will be entered: ");
        int integers_entered = input.nextInt();
        
        int numbers_entered[] = new int [integers_entered];
        
        //add integers entered by user to a list
        for(int i = 0; i < numbers_entered.length; i++)
        {
            System.out.print("Enter a number between one and fifty: ");
            numbers_entered[i] = input.nextInt();
        }
        
        frequency(numbers_entered, integers_entered);
    }
    
    private static void frequency (int arr[], int n) {
    
        boolean[] visited = new boolean[n];

        for (int i = 0; i < n; i++) { 

            //skip this element if already processed 
            if (visited[i] == true) 
                continue; 

            Arrays.fill(visited, false); 

            //count frequency 
            int count = 1; 
            for (int j = i + 1; j < n; j++) { 
                if (arr[i] == arr[j]) { 
                    visited[j] = true; 
                    count++; 
                }}
            

        System.out.println(arr[i] + " occurs " + count + " time(s)");

        }
    }
}

    
        
            
            
            