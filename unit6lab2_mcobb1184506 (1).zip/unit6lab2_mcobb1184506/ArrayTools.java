/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraytoolstest;

import java.util.Arrays;

/**
 *
 * @author marie
 */
public class ArrayTools {
    //MINIMUM
    public static char minimum(char array[])
    {
        char array_copy [] = array.clone();
        Arrays.sort(array_copy);
        char minimum = array_copy [0];
        return minimum;
    }

    public static int minimum(int array[])
    {
        int smallest = 300000000;
        for (int x:array)
        {
            if (x<smallest)
                smallest = x;
        }
        return smallest;
    }

    public static double minimum(double array[])
    {
        double smallest = 300000000.00000000;
        for (double x:array)
        {
            if (x<smallest)
                smallest = x;
        }
        return smallest;
    }

//MAXIMUM    
    public static char maximum(char array[])
    {
        char array_copy [] = array.clone();
        Arrays.sort(array_copy);
        char maximum = array_copy [array_copy.length - 1];
        return maximum;
    }

    public static int maximum(int array[])
    {
        int max_index = 0;
        int largest = -300000000;
        for (int x:array) {
            if (x>largest) {
                largest = x;
            }}
        return largest;      


    }

    public static double maximum(double array[])
    {
        double largest = -300000000.00000000;
        for (double x:array)
        {
            if (x>largest)
                largest = x;
        }
        return largest;
    }

//MINIMUM AT

    public static int minimumAt(char array[])
    {

        int smallest = 0;
        for (int x=0; x<array.length; x++) {
            if (array[x]<array[smallest]) {
                smallest = x;      
        }}
        return smallest;
    }

    public static int minimumAt(int array[])
    {
        int min_index=-1;
        int smallest = 300000000;
        for (int x=0; x<array.length; x++) {
            if (array[x]<smallest) {
                smallest = array[x];
                min_index = x;      
        }}
        return min_index;
    }

    public static int minimumAt(double array[])
    {
        int min_index=0;
        double smallest = 300000000.00000;
        for (int x=0; x<array.length; x++) {
            if (array[x]<smallest) {
                smallest = array[x];
                min_index = x;      
        }}
        return (int) min_index;
    }

//MAXIMUM AT
    public static int maximumAt(char array[])
    {
        int largest = 0;
        for (int x=0; x<array.length; x++) {
            if (array[x]>array[largest]) {
                largest = x;      
        }}
        return largest;
    }

    public static int maximumAt(int array[])
    {
        int largest = 0;
        for ( int i = 1; i < array.length; i++ )
        {
            if ( array[i] > array[largest] )
                largest = i;
        }
        return largest;
    }

    public static int maximumAt(double array[])
    {
        int largest=0;
        for (int x=1; x < array.length; x++) {
            if (array[x]>array[largest]) {
                largest = x;    
        }}
        return largest;
    }
//AVERAGE    
    public static double average (int array[])
    {
        int average = 0;
        for (int x=0; x>array.length; x++)
            average = average + array[x];
        return average;
    }

    public static double average (double array[])
    {
        double average = 0.00;
        for (int x=0; x>array.length; x++)
            average = average + array[x];
        average = average / array.length;
        return average;
    }
}

    

