/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraytoolstest;

/**
 *
 * @author marie
 */
public class ArrayToolsTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        char char_list[] = {'N', 'C', 'A', 'X', 'W', 'P'};
        System.out.println("mimimum value of the character list: " + ArrayTools.minimum(char_list));
        System.out.println("maximum value of the character list: " + ArrayTools.maximum(char_list));
        System.out.println("index location of the maximum value of the character list: " + ArrayTools.maximumAt(char_list));
        System.out.println("index location of the minimum value of the character list: " + ArrayTools.minimumAt(char_list));
       
        int int_list[] = {34, 23, 654, 234, 45, 65, 43, 765, 3};
        System.out.println("minimum value of the integer list: " + ArrayTools.minimum(int_list));
        System.out.println("maximum value of the integer list: " + ArrayTools.maximum(int_list));
        System.out.println("index location of the maximum value of the integer list: " + ArrayTools.maximumAt(int_list));
        System.out.println("index location of the minimum value of the integer list: " + ArrayTools.minimumAt(int_list));
       
        double double_list[] = {54.34, 23.2, 3456.45, 767.45, 6.2, 18.1};
        System.out.println("minimum value of the double list: " + ArrayTools.minimum(double_list));
        System.out.println("maximum value of the double list: " + ArrayTools.maximum(double_list));
        System.out.println("index location of the maximum value of the double list: " + ArrayTools.maximumAt(double_list));
        System.out.println("index location of the minimum value of the double list: " + ArrayTools.minimumAt(double_list));
        
    }
    
}
