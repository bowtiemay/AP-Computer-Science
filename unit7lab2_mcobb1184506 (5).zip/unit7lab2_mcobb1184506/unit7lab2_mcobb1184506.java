/*
 * This program converts between different number systems (decimal, binary, and hexadecimal)
 */
package unit7lab2_mcobb1184506;

import java.util.Scanner;

/**
 *
 * @author marie
 */
public class Unit7lab2_mcobb1184506 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner (System.in);
        
        // the main method is all dedicated to testing different values
        System.out.print("Enter a binary number: ");
        int num_step = input.nextInt();
        String binaryString = String.valueOf(num_step);
        
        System.out.println(num_step + " as a decimal number is " + binaryToDecimal(binaryString));
        System.out.println(num_step + " as a hexadecimal number is " + binaryToHex(binaryString));
        
        System.out.println();
        
        System.out.print("Enter a decimal number: ");
        int decimalNumber = input.nextInt();
        
        System.out.println(decimalNumber + " as a binary number is " + decimalToBinary(decimalNumber));
        System.out.println(decimalNumber + " as a hexadecimal number is " + decimalToHex(decimalNumber));
          
    }
    
    public static int binaryToDecimal (String binaryString)
    {
        int num = Integer.parseInt(binaryString);
        int dec_value = 0;
 
        // initializing base: value exponent to 1, ie 2^1
        int base = 1;
 
        int temp = num;
        while (temp > 0) {
            int last_digit = temp % 10;
            temp = temp / 10;
 
            dec_value += last_digit * base;
 
            base = base * 2;
        }
 
        return dec_value;
    }
    
    public static String binaryToHex (String number) 
    {
        //string to decimal
        int decimal = Integer.parseInt(number,2);
        //decimal to hex
        return Integer.toHexString(decimal);
        
    }
    
    public static String decimalToBinary (int decimalNumber)
    {
        //decimal to binary using handy dandy java conversion
        return Integer.toBinaryString(decimalNumber);
    }
    
    public static String decimalToHex (int decimalNumber)
    {
        return Integer.toHexString(decimalNumber);
    }
    
}
