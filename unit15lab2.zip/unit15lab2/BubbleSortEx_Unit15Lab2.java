/*
 * This program implements bubble sort, a simple yet inefficient sorting technique, to sort a given array.
 * Bubble sort is of O(n^2) complexity because the inner loop does O(n) work on each iteration, and the 
 * outer loop runs for O(n) iterations, so the total work is O(n^2).
 */
package bubblesortex_unit15lab2.unit15lab2_mcobb1184506;

/**
 *
 * @author Maya Cobb
 */
public class BubbleSortEx_Unit15Lab2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int array [] = {2, 9, 5, 4, 8, 1, 6};
        bubbleSort(array);
    }
    /**
     * preconditions: correct syntax with an integer list as a parameter
     * post-conditions: will sort the list in ascending order and will output the current list values on each pass through the method for loop.
     * @param list --> an integer list
     */
    public static void bubbleSort (int [] list)
    {
        //iterate through the list
        for(int i=0; i<list.length-1; i++)
        {
            
            for (int j = 1; j < list.length; j++) //iterate through the whole array each time to swap individual elements and place them in ascending order
            {
                if (list[j-1] >= list[j]) {
                    //set variable values for m and n so that one of their values doesn't get lost when we swap the values
                    int m = list[j-1]; 
                    int n = list[j];
                    //swap the values with the help of the set variables
                    list[j-1] = n;  
                    list[j] = m;
                   
                }     
            }
            //iterate through the array each pass and display the current list
            System.out.println("PASS " + (i+1) + ":");
            for (int n = 0; n < list.length; n++)
                System.out.print(list[n] + "     ");
            System.out.println("\n");
        }
    }
    
}
