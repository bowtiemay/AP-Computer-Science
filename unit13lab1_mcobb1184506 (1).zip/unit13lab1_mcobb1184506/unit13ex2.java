
/**
 * This program sets up a GUI interface for a loan calculator.
 *
 * @author Maya Cobb
 * @version February 5th, 2021
 */

import javafx.application.Application;

import javafx.scene.Scene;

import javafx.scene.control.Button;

import javafx.scene.control.Label;

import javafx.scene.control.TextField;

import javafx.scene.layout.GridPane;

import javafx.stage.Stage;

import javafx.geometry.HPos;

import javafx.geometry.Insets;

import javafx.geometry.Pos;

import javafx.scene.layout.FlowPane;

import javafx.geometry.*;

import javafx.scene.control.*;

public class unit13ex2 extends Application
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class unit13ex2
     */
    public void start(Stage myStage)
    {
        myStage.setTitle("Loan Calculator");
        GridPane rootNode = new GridPane();
        rootNode.setPadding(new Insets(30));
        rootNode.setHgap(5);
        rootNode.setVgap(5);
        
        Scene myScene = new Scene(rootNode, 300, 200);
        
        rootNode.add(new Label("Annual Interest Rate:"), 0, 0);
        rootNode.add(new TextField(), 1, 0);
        rootNode.add(new Label("Number of Years:"), 0, 1);
        TextField middleInitial = new TextField();
        rootNode.add(middleInitial, 1, 1);
        rootNode.add(new Label("Loan Amount:"), 0, 2);
        rootNode.add(new TextField(), 1, 2);
        rootNode.add(new Label("Monthly Payment"), 0, 3);
        rootNode.add(new TextField(), 1, 3);
        rootNode.add(new Label("Total Payment"), 0, 4);
        rootNode.add(new TextField(), 1, 4);
        rootNode.setAlignment(Pos.CENTER);
        
        Button aButton = new Button("Calculate");
        rootNode.add(aButton, 1, 5);
        rootNode.setHalignment(aButton, HPos.RIGHT);
        
        myStage.setScene(myScene);
        myStage.show();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public static void main(String [] args)
    {
        launch(args);
    }
}
