/*
This program creates a calculator
*/
//import classes
import javafx.application.Application;
import javax.swing.*;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import java.lang.Math; 
import javafx.scene.control.Button;
import java.math.RoundingMode;
import java.math.BigDecimal;
public class calcTest extends Application
{
    public static void main(String [] args)
    {
        //create jframe 
        JFrame j = new JFrame();
        Application.launch(args);
    }

    //create start method
    @Override
    public void start(Stage myStage)
    {
        //set title and labels
        myStage.setTitle("Simple Calculator");
        Label fv = new Label("First Value:            ");
        Label sv = new Label("Second Value:       ");
        Label si = new Label("Sum Is:                  ");
        //create text fields
        TextField firstValue = new TextField();
        TextField secondValue = new TextField();
                TextField sumIs = new TextField();
        //make the result field uneditable
        sumIs.setEditable(false);
        Button b = new Button("Calculate");
        b.setMaxSize(100,25);
        FlowPane rn = new FlowPane(fv, firstValue, sv, secondValue, si, sumIs, b);
        Scene myScene = new Scene(rn, 300, 200);
        //calculate result and display
        b.setOnAction(value -> 
        {
            double v1 = Double.parseDouble(firstValue.getText());
            double v2 = Double.parseDouble(secondValue.getText());
            double v3 = v1 + v2;
            sumIs.setText
                        (Double.toString(v3));
        });
        myStage.setScene(myScene);
        myStage.show();
    }
}