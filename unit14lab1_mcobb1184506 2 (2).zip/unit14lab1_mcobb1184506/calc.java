
/**
 * This program takes two values and outputs their sum. Uses JavaFX for output window and formatting.
 *
 * @author Maya Cobb
 * @version 2/13/2021
 */

import javafx.application.Application;

import javafx.scene.Scene;

import javafx.scene.control.Button;

import javafx.scene.control.Label;

import javafx.scene.control.TextField;

import javafx.scene.layout.GridPane;

import javafx.stage.Stage;

import javafx.geometry.HPos;

import javafx.geometry.Insets;

import javafx.geometry.Pos;

import javafx.scene.layout.FlowPane;

public class calc extends Application
{
    // instance variables - replace the example below with your own
    private Label firstValueLabel;
    private Label secondValueLabel;
    private Label sumLabel;

    /**
     * Constructor for objects of class unit13ex1
     */
    public void start (Stage myStage)
    {
        // initialise instance variables
        myStage.setTitle("Unit 14 Lab 1");
        FlowPane rootNode= new FlowPane();
        Scene myScene = new Scene(rootNode, 300, 200);
        //firstValueLabel = new Label("First value:");
        //secondValueLabel = new Label("Second value:");
        Label myLabel = new Label("First Value:  ");
        TextField textField1 = new TextField();
        Label myLabel2 = new Label("       Second Value: ");
        TextField textField2 = new TextField();
        Label myLabel3 = new Label("    Sum:  ");
        TextField textField3 = new TextField();
        textField3.setEditable(false);
        textField1.setPrefColumnCount(10);
        
        Button button = new Button("Calculate");
        
        button.setOnAction(value -> 
        {
            double value1 = Double.parseDouble(textField1.getText());
            double value2 = Double.parseDouble(textField2.getText());
            double value3 = value1 + value2;
            textField3.setText(Double.toString(value3));
        });
        rootNode.getChildren().addAll(myLabel, textField1, myLabel2, textField2, myLabel3, textField3, button); 
        myStage.setScene(myScene);
        myStage.show();
    }
}