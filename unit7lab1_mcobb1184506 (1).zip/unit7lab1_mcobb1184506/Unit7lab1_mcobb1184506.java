/*
 * This program reads words from the command line and returns the word count of each word and the number of words inputted.
 */
package unit7lab1_mcobb1184506;

/**
 *
 * @author Maya Cobb
 */
public class Unit7lab1_mcobb1184506 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int counter;
        int wordCount = args.length;
        
        for (int i = 0; i < args.length; i++) {
            counter = 0;
            for (int j = 0; j < args[i].length(); j++) {
                //System.out.println(args[i]);
                counter++;
                }
            System.out.println("letter count of word " + (i+1) + ": " + counter);
        }
        
        System.out.println("number of words inputted into the command line: " + wordCount);
}              
}       
        
        
   
    