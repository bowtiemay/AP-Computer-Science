/*
 * This class provides code for the DivideByZeroExeption that extends the Java built in 
 * exeption class that can be used by programs that use division.
 * 
 */
package checkexception5exercise;

/**
 *
 * @author Maya Cobb
 */
public class DivideByZeroException extends Exception {
    
    private int denom; //initilalize private int denom
    
    public DivideByZeroException()
    {
        
    }
    
    public DivideByZeroException (String s)
    {
        super (s);
    }
    
    public DivideByZeroException (int d)
    {
        super("div by zero");
        denom = d;       
    }
  
    public int getDenominator()
    {
        return denom;
    }
}
