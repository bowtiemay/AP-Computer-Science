/*
 * This program will prompt the user for a divisor and a dividend, and if the
 * user enters zero for the dividend, the method will throw a DivideByZeroException
 * which will prompt the user to try again. This will occur until the user enters
 * a nonzero dividend.
 */
package checkexception5exercise;

import java.util.Scanner;

/**
 *
 * @author Maya Cobb
 */
public class CheckException5exercise {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        tryIt(); //call the tryIt method
        
    }  
        
    /*
    * preconditions: correct syntax in calling the method
    * postconditions: will prompt the user for a divisor and a dividend, and if the
    * user enters zero for the dividend, the method will throw a DivideByZeroExeption
    * which will prompt the user to try again. This will occur until the user enters
    * a nonzero dividend.
    */
    public static void tryIt ()
    {
        try 
        {
            System.out.println();
            Scanner input = new Scanner (System.in);  //create scanner

            //ask user for the dividend and set the dividend to the user input
            System.out.print("Enter a number to be the dividend: ");
            int dividend = input.nextInt();

            //ask user for the divisor and set the divisor to the user input
            System.out.print("Enter a number to be the divisor: ");
            int divisor = input.nextInt();
            
            //call the divide method and print the result
            System.out.println("Quotient: " + divide(dividend, divisor));
            System.out.println();
        }
        
        catch (DivideByZeroException e)
        {
            System.out.println("divide by zero error - please try again.");
            tryIt();
        }
        
    }
    
    /*
    * preconditions: correct sytax, enter integer values x and y
    * postconditions: will return the quotiont of x divided by y
    */
    public static int divide (int x, int y) throws DivideByZeroException
    {
        int result = 0; //intialize int result variable to 0
        try
        {
            result = x/y; //divide x by y
        }
        catch (ArithmeticException e)
        {
            throw new DivideByZeroException(y);  //throw a DivideByZeroException if y=0
        }
        return result;  //return result of division
    }
    
}
