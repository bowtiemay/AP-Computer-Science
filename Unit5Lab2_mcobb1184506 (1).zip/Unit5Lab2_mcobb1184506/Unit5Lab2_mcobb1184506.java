/*
 * This program takes a month and a year input and returns a calendar for that given month and year
 */
package unit5lab2_mcobb1184506;

import java.util.Scanner;

/**
 *
 * @author marie
 */
public class Unit5Lab2_mcobb1184506 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner (System.in);
        
        System.out.print("Enter the numeric value of a month (ex. 4 is april, 12, is december): ");
        int month = input.nextInt();
        
        int day = 2;
        
        
        System.out.print("Enter the year (using 4 digits): ");
        int year = input.nextInt();
        
        printMonthCalendar(month, day, year);
        
    }    
    
    //PRINT FINAL CALENDAR RESULT
    
    private static void printMonthCalendar(int month, int day, int year)    
    {
        System.out.println("leap year?: " + isLeapYear(year));
        System.out.println(printMonthHeader(month, year));
        printMonthBody(month, day, year);
        //System.out.println(getStartDay(month, day, year));

    }
    
    //PROVIDED METHOD- GET THE STARTING DAY OF THE SPECIFIED MONTH
    
    public static int getStartDay( int m, int d, int y )
        {
          // Adjust month number & year to fit Zeller's numbering system
          if ( m < 3 ) 
          {
            m = m + 12;
            y = y - 1;
          }
          
          int k = y % 100;      // Calculate year within century
          int j = y / 100;      // Calculate century term
          int h = 0;            // Day number of first day in month 'm'

          h = ( d + ( 13 * ( m + 1 ) / 5 ) + k + ( k / 4 ) + ( j / 4 ) + ( 5 * j ) ) % 7;

          // Convert Zeller's value to ISO value (1 = Mon, ... , 7 = Sun )
          int dayNum = ( ( h + 5 ) % 7 ) + 1;     

          return dayNum;
        }
    
    //DETERMINE WHETHER OR NOT SPECIFIED YEAR IS A LEAP YEAR
  
    private static boolean isLeapYear (int year) {
        
        boolean a;
        
        if (year%4 == 0)
            a = true;
        else 
            a = false;
        return a;
  
}
    
    //ASSIGN MONTH NAME BASED ON NUMBER
    
    private static String getMonthName(int month, int year)
    {
        int n = month;
        String m = "starter";
        
        if (n == 1)
                m = "January";
        if (n == 2)
                m = "February";
        if (n == 3)
                m = "March";
        if (n == 4)
                m = "April";
        if (n == 5)
                m = "May";
        if (n == 6)
                m = "June";
        if (n == 7)
                m = "July";
        if (n == 8)
                m = "August";
        if (n == 9)
                m = "September";
        if (n == 10)
                m = "October";
        if (n == 11)
                m = "November";
        if (n == 12)
                m = "December";
        
        return m;
    }
    
    //PRINT A MONTH HEADER
    
    private static String printMonthHeader(int month, int year)
        {
        
        String dashes = "----------------------------";
        String dayNames = "Sun Mon Tue Wed Thu Fri Sat";
        
        return "\t" + getMonthName(month, year) + " " + year + "\n" + dashes + "\n" + dayNames + "\n";
       
    }
    
    // GET THE NUMBER OF DAYS IN THE SPECIFIED MONTH
    
    private static int getNumDaysInMonth(int month, int year)
    {
        int days = 0;
        //boolean a = true; 
        if (month == 1)
            days = 31;
        if (month == 2)
            days = isLeapYear(year) ? 29 : 28;
        if (month == 3)
            days = 31;  
        if (month == 4)
            days = 30;
        if (month == 5)
            days = 31;
        if (month == 6)
            days = 30;
        if (month == 7)
            days = 31;
        if (month == 8)
            days = 31;
        if (month == 9)
            days = 30;
        if (month == 10)
            days = 31;
        if (month == 11)
            days = 30;
        if (month == 12)
            days = 31;
        
        return days;
    }
    
    //PRINT THE BODY OF THE CALENDAR

    static void printMonthBody(int year, int day, int month) {
       
        int startDay = getStartDay(year, day, month);

        int numberOfDaysInMonth = getNumDaysInMonth(year, month);
        
        int i = 0;
        for (i = 0; i < (startDay-1); i++)
          System.out.print("    ");
        for (i = 1; i <= numberOfDaysInMonth; i++) {
          if (i < 10)
            System.out.print(i + "   ");
          else
            System.out.print(i + "  ");
          if ((i + (startDay-1)) % 7 == 0)
            System.out.println();
        }
        System.out.println();

    }
}

 

    