/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
        
package unit4lab1_mcobb1184506;

import java.util.Scanner;

/**
 *
 * @author marie
 */
public class Unit4Lab1_mcobb1184506 {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        
        // create play_again boolean
        boolean play_again = true;
        
        // create a game number counter
        int game_number = 0;
            
        
        while (play_again == true)
        {
            game_number++;
            System.out.println("\n------------------------------------------GAME " + game_number + "--------------------------------------------------");
            
            // Use a Scanner to input integer values
            Scanner input = new Scanner( System.in );
            // Use a Scanner to input integer values
            System.out.print( "\nWhat is the highest number of your preferred range?: " );
            int range = input.nextInt();     // Input range
            System.out.print( "What is the maximum numbers of guesses that you want to make?: " );
            int mg = input.nextInt();     // Input max guesses

            //create a guess counter variable
            int g; 

            // calculate secret number
            int random = ((int) ( range * Math.random() ) + 1);

            for (g = 1 ; g <= mg ; g = g + 1)
            {
                System.out.println();
                System.out.print("Guess the secret number!: ");
                int n = input.nextInt();
                if (n > random)
                    System.out.print("guess " + g + ": too high \n");
                if (n < random)
                    System.out.print("guess " + g + ": too low \n");
                if (n == random)
                {
                    System.out.print("Correct \n");
                    break;
                }
            }
            System.out.print("\nYou want to play this game again (true or false): ");
            play_again = input.nextBoolean();

            }


                
        
        
        
    }   
}



