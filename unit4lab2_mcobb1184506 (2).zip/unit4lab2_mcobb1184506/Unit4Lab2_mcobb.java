/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unit4lab2_mcobb;

import java.util.Scanner;

/**
 *
 * @author marie
 */
public class Unit4Lab2_mcobb {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Use a Scanner to input integer values
        Scanner input = new Scanner( System.in );
        // ask user for greatest number of asterisks
        System.out.print( "\nHow many asterisks?: " );
        int asterisks = input.nextInt();     // variable for asterisk number
        
        int i = asterisks;
        int rows = asterisks;
        
        int j;
        
        for(i=0; i < asterisks-2; i++)
            {     
            for(j = asterisks; j>=i+1; j--)
            {
                System.out.print("*");
            }
            System.out.println();
        }  
        if (asterisks != 1)
            {
            System.out.println("**"+"\n"+"*");
        }
        if (asterisks == 1)
        {
            System.out.println("*");
        }
    }
    
}
