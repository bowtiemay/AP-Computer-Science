package Unit3Lab1_mcobb1184506;

import java.util.Scanner;

public class unit3lab1_mcobb1184506
{

    /**
     *
     * @param args
     */
    public static void main( String [] args )
  {
    // Define and initialize variables for values to be input
    int side1;      // First value to be input
    int side2;      // Second value to be input
    int side3;      // Third value to be input
  
    // Use a Scanner to input integer values
    Scanner input = new Scanner( System.in );
    // Use a Scanner to input integer values
    System.out.println( "\n" );
    System.out.print( "Enter the side lengths of a triangle (each followed by a blank space): " );
    side1 = input.nextInt();     // Input first value
    side2 = input.nextInt();     // Input second value
    side3 = input.nextInt();     // Input third value
    
    //System.out.print( "\n" + "Enter the smallest side length of your triangle: " );
    //side1 = input.nextInt();     // Input first value
    //System.out.print( "\n" + "Enter the second smallest side length of your triangle: " );
    //side2 = input.nextInt();     // Input second value
    //System.out.print( "\n" + "Enter the largest side length of your triangle: " );
    //side3 = input.nextInt();     // Input third value
    
    if (((side1 + side2)<= side3) | ((side1 + side3) <= side2) | ((side2 + side3)<= side1)) 
    {   
        System.out.println("\n" + "You entered the values " + side1 + ", " + side2 + ", and " + side3 + ". The values entered do not make a valid triangle.");
    }
    
    else if ((side1 + side2) > side3) {
      
      if ((side1==side2) & (side2==side3) & (side3==side1)){
          System.out.println("\n" + "The values " + side1 + ", " + side2 + ", and " + side3 + " represent an equilateral triangle.");
  }
      if (((side1 == side2) | (side1 == side3) | (side2 == side3)) & ((side1 != side3) | (side2 != side3) | (side1 != side2))) {
        System.out.println("\n" + "The values " + side1 + ", " + side2 + ", and " + side3 + " represent an isosceles triangle.");
    } 
      if ((side1 != side2) & (side2 != side3) & (side1 != side3)){
          System.out.println("\n" + "The values " + side1 + ", " + side2 + ", and " + side3 + " represent a scalene triangle.");
                  
      }
      
    }
    
   
    System.out.println();
    
   
  }}
