/*
 * This program uses the java.util.Random import to generate a set of random numbers from a given set of numbers.
 */
package unit5activity1q4;

import java.util.Random;

/**
 *
 * @author marie
 */
public class Unit5activity1Q4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        for (int i = 1; i <= 100; i++)
        {
            int[] randomNumbers = new int[] { 2, 3, 5, 7, 11, 13, 17, 19 };
            Random r = new Random();
            int nextRandomNumberIndex = r.nextInt(randomNumbers.length);
            System.out.println(randomNumbers[nextRandomNumberIndex]);

        }    
    }
}

    
    

