/*
 * This program takes an input angle measure in degrees and outputs the angle measure in degrees, the angle measure in radians, and 
 * the sine, cosine, and tangent of the angle entered by utilizing the built-in Java math method.
 */
package unit5activity1q2;

import java.util.Scanner;

/**
 *
 * @author marie
 */
public class Unit5activity1Q2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.print("Enter an angle measure in degrees: ");
        double degrees = input.nextDouble();
        double radians = Math.toRadians(degrees);
        double sine = Math.sin(radians);
        double cosine = Math.cos(radians);
        double tangent = Math.tan(radians);
        
        System.out.println("\nThe measure of the angle entered in degrees is " + degrees);
        System.out.println("The measure of the angle entered in radians is " + radians);
        System.out.println("The sine of the angle entered is " + sine);
        System.out.println("The cosine of the angle entered is " + cosine);
        System.out.println("The tangent of the angle entered is " + tangent);
        
    }
    
}
