/*
 * This program uses the Math.random function to generate a set of twenty random numbers.
 */
package unit5activity1q3;


/**
 *
 * @author marie
 */
public class Unit5activity1Q3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
  
        for (int i = 1; i<=20; i++)
        {
            int m = (int) ((Math.random() * 5)+1);
            System.out.print(m + " ");
        }

        System.out.println();
    }
    
    
}
