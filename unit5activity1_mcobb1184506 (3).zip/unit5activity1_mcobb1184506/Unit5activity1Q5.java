/*
 * This program prompts the user to enter two numbers x and y, and then displays the value of x/y 
 * rounded to an integer value, to one decimal place, and to two decimal places. 
 */
package unit5activity1q5;

import java.util.Scanner;

/**
 *
 * @author marie
 */
public class Unit5activity1Q5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner (System.in);
        
        System.out.print("Enter a number for the x value: ");
        double x = input.nextInt();
        
        System.out.print("Enter a number for the y value: ");
        double y = input.nextInt();
        
        double d = x/y;
        
        int int_value = (int) (Math.floor(d * 1 + 0.5) / 1);
        double one_decimal = Math.floor(d * 10 + 0.5) / 10;
        double two_decimal = Math.floor(d * 100 + 0.5) / 100;
        double three_decimal = Math.floor(d * 1000 + 0.5) / 1000;
        
        System.out.println();
        System.out.println("The rounded integer value of x/y is: " + int_value);
        System.out.println("x/y rounded to one decimal place is: " + one_decimal);
        System.out.println("x/y rounded to two decimal places is: " + two_decimal);
        System.out.println("x/y rounded to three decimal places is: " + three_decimal);
        
        System.out.println("\nWarning: the division result may not need to be rounded to more than a given number of decimal places.");
        
        
    }
    
}
