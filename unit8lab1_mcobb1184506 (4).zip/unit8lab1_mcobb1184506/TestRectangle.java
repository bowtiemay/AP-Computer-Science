/*
 * 
 */
package testrectangle.unit8lab1_mcobb1184506;

/**
 *
 * @author marie
 */
public class TestRectangle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Rectangle rectangle = new Rectangle();
        
        rectangle.whichCharacter();
        rectangle.setLength(30);
        rectangle.setWidth(30);
        
        System.out.println();
        rectangle.makeRectangle();
        
        rectangle.findArea();
        rectangle.findPerimeter();
        
        System.out.println();
                
    }
    
}
