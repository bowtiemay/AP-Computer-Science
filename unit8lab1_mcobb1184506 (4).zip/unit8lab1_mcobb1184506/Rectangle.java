/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testrectangle;

import java.util.Scanner;

/**
 *
 * @author marie
 */
public class Rectangle {
    
    Scanner input = new Scanner(System.in);
    
    private int length;
    private int width;
    private char character;
    
    public Rectangle() //default values
    {
        length = 1;
        width = 1;
    }
    
    public void whichCharacter () //select which character to use to build the rectangle
    {
        System.out.print("Specify a letter that you would like to use to build your rectangle: ");
        character = input.next().charAt(0);
    }
    
    public int getLength()
    {
        return length;
    }
    
    public int getWidth()
    {
        return width;
    }
    
    public char getCharacter()
    {
        return character;
    }
    
    public void setLength (int x)
    {
        if (x>=0 && x<=30)
            length = x;
        else 
            error_msg();
    }
    
    public void setWidth (int y)
    {
        if (y>=0 && y<=30)
            width = y;
        else
            error_msg();
    }
    
    private void error_msg()
    {
        System.out.print("  error: value must be positive and 30 or less. restart program and try again.");
    }
    
    public void findArea()
    {
        double area = length * width;
        System.out.println("area = " + area);
    } 
    
    public void findPerimeter()
    {
        double perimeter = 2*length + 2*width;
        System.out.println("perimeter = " + perimeter);
    }
          
    public void makeRectangle()
    {
        makeRectangleTop();
        makeRectangleBottomAndSides();
    }
        
    private void makeRectangleTop()
    {
        for (int i = 0; i < width; i++)
            System.out.print(character);       
    }
    
    private void makeRectangleBottomAndSides()
    {
        
        for (int j = 0; j < length-2; j++)
        {
            System.out.println();
            
            System.out.print(character);
            
            for (int k = 0; k < width-2; k++)
                System.out.print(" ");
            System.out.print(character);            
        }
        
        System.out.println();
        
        for (int i = 0; i < width; i++)
            System.out.print(character);
        
        System.out.println("\n");
            
    }
    
  
}
