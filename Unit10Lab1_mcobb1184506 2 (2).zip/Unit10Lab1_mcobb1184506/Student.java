/*
 * This class contains the methods for a student object.
 */
package unit10lab1test;

/**
 *
 * @author Maya Cobb
 */
public class Student extends Person {
    
    private String classStatus;
    
    public Student ()
    {
        classStatus = "no class status";
    }
    
    //set freshman, sophomore, junior, or senior
    public void setClassStatus (String grade)
    {
        classStatus = grade;
    }
    
    public String getClassStatus ()
    {
        return classStatus;
    }
    
    public String toString ()
    {
        return "Student\n" + getName();
    }
}
