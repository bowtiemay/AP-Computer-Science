/*
 * This class contains the methods for a faculty object, and is a child class of the Employee class.
 */
package unit10lab1test;

/**
 *
 * @author Maya Cobb
 */
public class Faculty extends Employee {
    
    private String officeHours;
    private String rank;
    
    public Faculty ()
    {
        officeHours = "00:00 to 00:00";
        rank = "no rank";
    }
    
    public void setOfficeHours (String officehours)
    {
        officeHours = officehours;
    }
    
    //set rank to instructor, assistant instructor, or professor
    public void setRank (String r)
    {
        rank = r;
    }
    
    public String getOfficeHours ()
    {
        return officeHours;
    }
    
    public String getRank ()
    {
        return rank;
    }
    
    public String toString ()
    {
        return "Faculty" + "\n" + getName();
    }
}
