/*
 * This program tests various class methods.
 */
package unit10lab1test;

/**
 *
 * @author Maya Cobb
 */
public class Unit10lab1Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Person [] personArray = {new Person(), new Student(), new Employee(), new Faculty(), new Staff()};
        
        for (int i = 0; i<personArray.length; i++)
        {
            personArray[i].toString();
        }
        
        Person person = new Person();
        
        person.setName("Samantha Eisen");
        person.setAddress("819 Arlington Ave");
        person.setEmail("sameisen02@gmail.com");
        person.setPhoneNumber("415-324-6456");
        person.setBirthDate(3, 23, 2);
        System.out.println(person.toString());
        
        //System.out.println(person.getBirthDate());
        
        System.out.println();
        
        Student student = new Student();
        
        student.setClassStatus("sophomore");
        student.setName("Miriam Goldstein");
        student.setAddress("2341 Key Route");
        student.setEmail("miriamg3p@gmail.com");
        student.setPhoneNumber("415-765-3453");
        student.setBirthDate(6, 6, 2005);
        System.out.println(student.toString());
        
        System.out.println();
        
        Employee employee = new Employee();
        
        employee.setSalary(123123);
        employee.setHireDate(4, 7, 2012);
        employee.setName("Medina Lam");
        employee.setAddress("654 Cherry Lane");
        employee.setEmail("medinalam@gmail.com");
        employee.setPhoneNumber("415-233-5439");
        employee.setBirthDate(11, 8, 1998);
        System.out.println(employee.toString());
        
        System.out.println();
        
        Faculty faculty_member = new Faculty();
        
        faculty_member.toString();
        faculty_member.setOfficeHours("1:00 to 4:00");
        faculty_member.setRank("professor");
        faculty_member.setName("Sam Rozen");
        faculty_member.setAddress("77 Grizzly Road");
        faculty_member.setEmail("samrozen@gmail.com");
        faculty_member.setPhoneNumber("415-454-1294");
        faculty_member.setBirthDate(1, 23, 1990);
        System.out.println(faculty_member.toString());
        
        Staff staff = new Staff();
        
        staff.toString();
        
        
    }
    
}
