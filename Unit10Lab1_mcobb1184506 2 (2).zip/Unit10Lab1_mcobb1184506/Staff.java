/*
 * This class defines methods for a Staff object, and is a subclass of the Employee class.
 */
package unit10lab1test;

/**
 *
 * @author Maya Cobb
 */
public class Staff extends Employee {
    
    private String jobTitle;
    
    public Staff ()
    {
        jobTitle = "no job title";
    }
    
    public void setJobTitle (String job)
    {
        jobTitle = job;
    }
    
    public String getJobTitle ()
    {
        return jobTitle;
    }
    
    public String toString ()
    {
        return "Staff" + "\n" + getName();
    }

    
}
