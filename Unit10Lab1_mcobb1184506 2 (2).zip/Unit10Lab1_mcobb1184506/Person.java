/*
 * This program defines the methods for the Person parent class.
 */
package unit10lab1test;

/**
 *
 * @author Maya Cobb
 */
public class Person {
    
    private String name;
    private String address;
    private String email;
    private String phoneNumber;
    
    private Date birthDate;
    
    private int month;
    private int day;
    private int year;
    
    /**
    public Person ()
    {
        name = "no name";
        address = "no address";
        email = "no email";
        phoneNumber = "no phone number";
    }
    */
    public void setBirthDate (int m, int d, int y)
    {
        month = m;
        day = d;
        year = y;
        
        /**birthDate.setMonth(m);
        birthDate.setDay(d);
        birthDate.setYear(y);
        */
    }
    
    public void setName (String n)
    {
        name = n;
    }
    
    public void setAddress (String a)
    { 
        address = a;
    }
    
    public void setEmail (String e)
    {
        email = e;
    }
    
    public void setPhoneNumber (String phone)
    {
        phoneNumber = phone;
    }
    
    public String getName ()
    {
        return name;
    }
    
    public String getAddress ()
    {
        return address;
    }
    
    public String getEmail ()
    {
        return email;
    }
    
    public String getPhoneNumber ()
    {
        return phoneNumber;
    }
    
    public String getBirthDate ()
    {
        return month + "/" + day + "/" + year;
    }
    
    public String toString ()
    {
        return "Person \n" + name;
    }
}
