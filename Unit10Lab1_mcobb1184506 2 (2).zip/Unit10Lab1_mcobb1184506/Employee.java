/*
 * This class contains the methods for an employee object.
 */
package unit10lab1test;

/**
 *
 * @author Maya Cobb
 */
public class Employee extends Person {
    
    private double salary;
    private Date hireDate;
    
    private int month;
    private int day;
    private int year;
    
    public Employee ()
    {
        salary = 000.00;
    }
    
    public void setSalary (double s)
    {
        salary = s;
    }
    
    public void setHireDate (int m, int d, int y)
    {
        month = m;
        day = d;
        year = y;
    }
    
    
    public double getSalary()
    {
        return salary;
    }
    
    public String getHireDate()
    {
        return month + "/" + day + "/" + year;
    }
    
    public String toString ()
    {
        return "Employee" + "\n" + getName();
    }
}
