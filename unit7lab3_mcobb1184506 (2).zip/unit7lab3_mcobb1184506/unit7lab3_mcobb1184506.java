/*
 * This program takes three words and returns them in alphabetical order
 */
package unit7lab3_mcobb1184506;

import java.util.Scanner;

/**
 *
 * @author maya
 */
public class Unit7lab3_mcobb1184506 {

    /**
     * @param args the command line arguments
     */
    public static void main( String [] args )
{
        //prompt user to enter 3 words
        Scanner input = new Scanner (System.in);
        
        System.out.print("Enter a word: ");
        String e = input.nextLine();
        
        System.out.print("Enter a second word: ");
        String f = input.nextLine();
        
        System.out.print("Enter a third word: ");
        String g = input.nextLine();
                                  
        System.out.println();
        
        //call method that returns and displays words in alphabetical order
        sortWords(e, f, g);
                                  
}
    public static void sortWords (String word1, String word2, String word3)
    {
        //use compareTo method to help determine the alphabetical order using ASCII values
        int a = word1.compareTo(word2);
        int b = word2.compareTo(word3);
        int c = word3.compareTo(word1);
        
        //create booleans to help compare the values of each word's letter's ASCII/lexicographic value
        boolean word1largerthanword2;
        boolean word2largerthanword3;
        boolean word3largerthanword1;
        
        if (a>1) {
            word1largerthanword2 = true;
        }
        else
            word1largerthanword2 = false;
        
        if (b>1) {
            word2largerthanword3 = true;
        }
        else
            word2largerthanword3 = false;
        
        if (c>1) {
            word3largerthanword1 = true;
        }
        else
            word3largerthanword1 = false;
        
        
        //print the list ordering depending on the boolean values found above
        
        if (word1largerthanword2 == true && word2largerthanword3 == true) {

            System.out.println(word3 + ", " + word2 + ", " + word1);
        }
        
        if (word1largerthanword2 == false && word2largerthanword3 == false) {
            
            System.out.println(word1 + ", " + word2 + ", " + word3);
        }
        
        if (word1largerthanword2 == true && word2largerthanword3 == false && word3largerthanword1 == false) {
            
            System.out.println(word2 + ", " + word3 + ", " + word1);
        }
        
        if (word1largerthanword2 == true && word2largerthanword3 == false && word3largerthanword1 == true) {
            
            System.out.println(word2 + ", " + word1 + ", " + word3);
        }
        
        if (word1largerthanword2 == false && word2largerthanword3 == true && word3largerthanword1 == false) {
            
            System.out.println(word3 + ", " + word1 + ", " + word2);
        }
        
        if (word1largerthanword2 == false && word2largerthanword3 == true && word3largerthanword1 == true) {
            
            System.out.println(word1 + ", " + word3 + ", " + word2);
        }
        
        
    }
}
