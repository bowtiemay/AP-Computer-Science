/*
 * This class creates a Car object with three attributes: a make (e.g., Acura), a model (e.g., 300C), and a year (e.g., 2019). 
 */
package cararraylists;

/**
 *
 * @author Maya Cobb
 */
public class Car {
    
    private String make; //make variable
    private String model; //model variable
    private int year; //year variable
    
    //car constructor
    public Car ()
    {
        make = "no make";
        model = "no model";
        year = 0;
    }
    
    //parameterized car constructor
    public Car (String inputMake, String inputModel, int inputYear)
    {
        make = inputMake;
        model = inputModel;
        year = inputYear;
    }
    
    //set the make of a car to a string value
    public void setMake (String inputMake)
    {
        make = inputMake;
    }
    
    //set the model of a car to a string value
    public void setModel (String inputModel)
    {
        model = inputModel;
    }
    
    //set the year that the car was made in
    public void setYear (int inputYear)
    {
        year = inputYear;
    }
    
    //get the make of the car object
    public String getMake ()
    {
        return make;
    }
    
    //get the model of the car object
    public String getModel ()
    {
        return model;
    }
    
    //get the year that the car was made
    public int getYear ()
    {
        return year;
    }
}
