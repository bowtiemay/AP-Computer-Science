/*
 * This program prompts the user to enter data for at five Car objects and stores them in an ArrayList. The program
 * iterates over the list and sorts any cars with vehicle years earlier than 2010 into an old cars ArrayList 
 * and those with vehicle years of 2010 and later into a new cars ArrayList. The program then displays
 * all three lists.
 */
package cararraylists;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Maya Cobb
 */
public class CarArrayLists {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner input = new Scanner (System.in); //create scanner
       
        //CREATE CAR OBJECT 1
        System.out.print("enter the make of car 1 (e.g. Mercedes-Benz): ");  //prompt for make
        String car1Make = input.nextLine();  //set make to a variable
        
        System.out.print("enter the model of car 1 (e.g. 300C): "); //prompt for model
        String car1Model = input.nextLine();  //set model to a variable
        
        System.out.print("enter the year in which car 1 was made (e.g. 2019): "); //prompt for year
        int car1Year = input.nextInt(); //set year to a variable
        
        Car car1 = new Car ();  //create car1 object
        car1.setMake(car1Make);  //set make
        car1.setModel(car1Model); //set model
        car1.setYear(car1Year); //set year
        
        System.out.println();
        
        //CREATE CAR OBJECT 2
        System.out.print("enter the make of car 2: "); 
        String car2Make = input.next(); 
        
        System.out.print("enter the model of car 2: ");
        String car2Model = input.next();
        
        System.out.print("enter the year in which car 2 was made: ");
        int car2Year = input.nextInt();
        
        Car car2 = new Car ();
        car2.setMake(car2Make);
        car2.setModel(car2Model);
        car2.setYear(car2Year);
        
        System.out.println();
        
        //CREATE CAR OBJECT 3
        System.out.print("enter the make of car 3: ");
        String car3Make = input.next();
        
        System.out.print("enter the model of car 3 (e.g. 300C): ");
        String car3Model = input.next();
        
        System.out.print("what is the year in which car 3 was made: ");
        int car3Year = input.nextInt();
        
        Car car3 = new Car (car3Make, car3Model, car3Year);
        
        System.out.println();
        
        //CREATE CAR OBJECT 4
        System.out.print("enter the make of car 4: ");
        String car4Make = input.next();
        
        System.out.print("enter the model of car 4: ");
        String car4Model = input.next();
        
        System.out.print("enter the year in which car 4 was made: ");
        int car4Year = input.nextInt();
        
        Car car4 = new Car ();
        car4.setMake(car4Make);
        car4.setModel(car4Model);
        car4.setYear(car4Year);
        
        System.out.println();
        
        //CREATE CAR OBJECT 5
        System.out.print("enter the make of car 5: ");
        String car5Make = input.next();
        
        System.out.print("enter the model of car 5: ");
        String car5Model = input.next();
        
        System.out.print("enter the year in which car 5 was made: ");
        int car5Year = input.nextInt();
        
        Car car5 = new Car ();
        car5.setMake(car5Make);
        car5.setModel(car5Model);
        car5.setYear(car5Year);
        
        System.out.println();
        
        
        //MAKE CAR OBJECT ARRAY LIST
        ArrayList <Car> cars = new ArrayList <Car> ();
        
        //add all of the car objects to the ArrayList
        cars.add(car1);  
        cars.add(car2);
        cars.add(car3);
        cars.add(car4);
        cars.add(car5);
        
        //MAKE AN ARRAYLIST OF CAR OBJECTS WHOSE YEAR IS LESS THAN 2010
        ArrayList <Car> oldCars = new ArrayList <Car> ();
        
        //MAKE AN ARRAYLIST OF CAR OBJECTS WHOSE YEAR IS GREATER THAN OR EQUAL TO 2010
        ArrayList <Car> newCars = new ArrayList <Car> ();
        
        //sort cars into oldCar and newCar arraylists
        for (int j = 0; j < cars.size(); j++)
        {
            if (cars.get(j).getYear() < 2010)
                oldCars.add(cars.get(j));
            if (cars.get(j).getYear() >= 2010)
                newCars.add(cars.get(j));
        }
        
        //PRINT ALL CAR OBJECT ARRAY LISTS
        
        //print original car object array list with all of the cars
        System.out.print("cars: ");
        
        for (int i = 0; i < cars.size(); i++)
        {
            if (cars.isEmpty())  //test if arrayList is empty
                System.out.println("this list is empty");
            else
                System.out.print(cars.get(i).getMake() + " "); 
        }
        
        System.out.println();
        
        //print oldCars array list
        System.out.print("old cars list: ");
        
        for (int i = 0; i < oldCars.size(); i++)
        {
            if (cars.isEmpty())
                System.out.println("this list is empty");
            else
                System.out.print(oldCars.get(i).getMake() + " ");
        }
        System.out.println();
        
        //print newCars array list
        System.out.print("new cars list: ");
        
        for (int i = 0; i < newCars.size(); i++)
        {
            if (cars.isEmpty())
                System.out.println("this list is empty");
            else
            {
                System.out.print(newCars.get(i).getMake() + " ");
            }
        }
        System.out.println();
    }
    
}
