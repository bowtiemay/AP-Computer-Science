/*
 * This class calls a a user interface on which users can manipulate counter and memory counter objects.
 */
package countertest;

/**
 *
 * @author Maya Cobb
 */
public class CounterTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        MemoryCounterConsoleMenu menu = new MemoryCounterConsoleMenu(); //creates a MemoryCounterConsoleMenu object
        
        menu.displayMenu(); //display the CounterConsoleMenu Object menu
        
        System.out.println();
        
        for (int i = 0; i<100; i++) {   //get the user input for up to 100 times to use the counter
            menu.getUserInput();
        }
    }
    
}
