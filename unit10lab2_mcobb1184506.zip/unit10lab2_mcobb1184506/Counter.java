/*
 * This counter class contains methods for a counter object.
 */
package countertest;

import java.text.DecimalFormat;

/**
 *
 * @author Maya Cobb
 */
public class Counter {
    
    private int myValue;  //counter object
    
    private final static String FORMAT = "00";  //format
    
    /**
     * preconditions: n/a - constructor
     * post conditions: sets default value of counter object to 0
     */
    public Counter () {
        myValue = 0;
    }

    /**
     * preconditions: type object name and method name correctly using the correct syntax, newValue must be an integer that you would
     * like set myValue to
     * post conditions: sets the value of myValue to newValue
     * @param newValue must be an integer that you would like to set myValue to
     */
    public void set (int newValue) 
    {
        myValue = newValue;
    }
    
     /**
     * preconditions: type object name and method correctly with the correct syntax
     * post conditions: will increment the value of the counter object by one
     */
    public void increment ()
    {
        myValue++;
    }
    
     /**
     * preconditions: type object name and method correctly with the correct syntax
     * post conditions: will decrement the value of the counter object by one
     */
    public void decrement ()
    {
        myValue--;
    }
    
     /**
     * preconditions: type object name and method correctly with the correct syntax
     * post conditions: will reset the value of the counter object to zero
     */
    public void reset ()
    {
        set(0);
    }
    
     /**
     * preconditions: type object name and method correctly with the correct syntax
     * post conditions: will return the current value of myValue
     */
    public int getValue() 
    {
        return myValue;
    }
    
     /**
     * preconditions: type object name and method correctly with the correct syntax
     * post conditions: will format the formatted value
     */
    public String toString() 
    {
        DecimalFormat fmt = new DecimalFormat(FORMAT);
        return fmt.format(myValue);
    }
}

