/*
 * This class creates a user interface on which users can create and manipulate counter and memory counter objects.
 */
package countertest;

import java.util.Scanner;

/**
 *
 * @author Maya Cobb
 */
public class MemoryCounterConsoleMenu  {
    
    MemoryCounter myMemCount = new MemoryCounter();
  
    Counter myCount = new Counter();
    
     /**
     * preconditions: type object name and method correctly using the correct syntax
     * post conditions: will issue an IllegalArgumentExeption with a message containing a string and the most recent myCount value
     */
    public void quit ()
    {
        throw new IllegalArgumentException ("you quit this program. final count = " + myCount.getValue());
    }
    
     /**
     * preconditions: type object name and method correctly using the correct syntax
     * post conditions: will display the current value of myCount
     */
    public void displayCount ()
    {
        System.out.println ("      count = " + myCount.getValue());
    }
    
    public void displayMemCount ()
    {
        System.out.println ("      memory count = " + myMemCount);
    }
    
     /**
     * preconditions: type object name and method correctly using the correct syntax
     * post conditions: will display a menu of options for a user of (in this case) getUserInput to select from
     */
    public void displayMenu ()
    {
        System.out.println("COUNTER MENU: increment, decrement, reset, quit, display count");
        System.out.println("MEMORY COUNTER MENU: add current value, reset memcount, display memcount");
    }
    
     /**
     * preconditions: type object name and method correctly with the correct syntax
     * post conditions: will prompt the user to select from the the options shown in displayMenu and based on the
     * user's selection, will utilize the increment, decrement, reset, quit, or display count methods that can be 
     * found in both the Counter class and this class
     */
    public void getUserInput ()
    {
        Scanner input = new Scanner (System.in);
        System.out.print("select an option from the menu above: ");
        String choice = input.nextLine();
        
        if (choice.equals("increment"))
            myCount.increment();
        
        if (choice.equals("decrement"))
            myCount.decrement();
        
        if (choice.equals("reset"))
            myCount.reset();
        
        if (choice.equals("quit"))
            quit();
        
        if (choice.equals("display count"))
            displayCount();
        
        if (choice.equals("add current value"))
            myMemCount.setMemCount();
        
        if (choice.equals("reset memcount"))
            myMemCount.resetMemCount();
        
        if (choice.equals("display memcount"))
            displayMemCount();
    }
}
