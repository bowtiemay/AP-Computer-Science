/*
 * This program throws an ArrayIndexOutOfBoundsException.
 */
package arrayindexoutofboundsexeptionthrown;

/**
 *
 * @author Maya Cobb
 */
public class ArrayIndexOutOfBoundsExeptionThrown {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int [] list = new int [5]; //create an int list
        
        //add elements to the int list
        list[0] = 5;
        list[1] = 6;
        list[3] = 2;
        list[4] = 8;
        list[5] = 7;
 
        //cycle through elements and print them
        for (int i = 0; i <= list.length; i++) //ArrayIndexOutOfBoundsException thrown here - list[6] is out of bounds, yet is included in the cycle
        {
            System.out.println("item: " + list[i]);
        }
        
        
        
    }
    
}
