/*
 * This program throws a ClassCastException by trying to cast an Integer object to a String.
 */
package classcastexceptionthrown;

/**
 *
 * @author Maya Cobb
 */
public class ClassCastExceptionThrown {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Object x = new Integer(0); //initialize and declare an integer value i
            
        //ClassCastException thrown here - String is not a subclass of integer, so this conversion is not possible
        System.out.println((String)x);
        
}
        
    
}
