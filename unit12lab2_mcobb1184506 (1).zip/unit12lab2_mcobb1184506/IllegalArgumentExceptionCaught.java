/*
 * This program throws and catches an IllegalArgumentException.
 */
package illegalargumentexceptioncaught;

import java.util.Scanner;

/**
 *
 * @author Maya Cobb
 */
public class IllegalArgumentExceptionCaught {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try
        {
            Scanner input = new Scanner (System.in); //new scanner
            
            System.out.print("Enter a number between 0 and 59, inclusive: ");  //get a number from 0-59
            int n = input.nextInt(); //set input to int variable n
            if (n < 0)  //if n is less than 0, throw an IllegalArgumentException
                throw new IllegalArgumentException("n must be positive");
            if (n >= 60)  //if n is greater than or equal to 60, throw an IllegalArgumentException
                throw new IllegalArgumentException("n must be < 60");
        }
        
        catch (IllegalArgumentException i)
        {
            System.out.println("An IllegalArgumentException was generated. This type of exception is generated \nwhen a method or value is passed an inappropreate argument or value. In this \nprogram, to generate an illegal argument exception, you must have entered a \nnegative number or a number above 59.");
        }
    }
    
}
