/*
 * This program throws an IllegalArgumentException.
 */
package illegalargumentexceptionthrown;

import java.util.Scanner;

/**
 *
 * @author Maya Cobb
 */
public class IllegalArgumentExceptionThrown {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner input = new Scanner (System.in); //new scanner
            
        System.out.print("Enter a number between 0 and 59, inclusive: ");  //get a number from 0-59
        int n = input.nextInt(); //set input to int variable n
        if (n < 0)  //if n is less than 0, throw an IllegalArgumentException
            throw new IllegalArgumentException("n must be positive");
        if (n >= 60)  //if n is greater than or equal to 60, throw an IllegalArgumentException
            throw new IllegalArgumentException("n must be < 60");
        
    }
        
    
}
