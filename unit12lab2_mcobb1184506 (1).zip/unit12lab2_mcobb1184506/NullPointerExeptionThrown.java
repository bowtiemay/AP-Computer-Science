/*
 * This program produces a NullPointerExeption by referring to an object that has a null value.
 */
package nullpointerexeptiontest;

/**
 *
 * @author Maya Cobb
 */
public class NullPointerExeptionThrown {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        npobject object = new npobject ();  //create a new object
        
        if (object.getObject() == null)  //throw a NullPointerException if an object is null - need to do this bc NullPointerExceptions are unchecked so will not be generated automatically
            throw new NullPointerException ();  //throw NullPointerException
        else
            System.out.println(object.getObject());  //print the value of the object if it's not null
        
    }
    
}
