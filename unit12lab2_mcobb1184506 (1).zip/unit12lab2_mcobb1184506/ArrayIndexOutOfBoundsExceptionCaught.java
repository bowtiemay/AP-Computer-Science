/*
 * This program throws and catches ArrayIndexOutOfBoundsExceptions
 */
package arrayindexoutofboundsexceptioncaught;

/**
 *
 * @author Maya Cobb
 */
public class ArrayIndexOutOfBoundsExceptionCaught {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try
        {
            int [] list = new int [5]; //create an int list
        
            //add elements to the int list
            list[0] = 5;
            list[1] = 6;
            list[3] = 2;
            list[4] = 8;
            list[5] = 7;

            //cycle through elements and print them
            for (int i = 0; i <= list.length; i++) //ArrayIndexOutOfBoundsException thrown here - list[6] is out of bounds, yet is included in the cycle
            {
                System.out.println("item: " + list[i]);
            }
        }
        catch (ArrayIndexOutOfBoundsException e)  //catch ArrayIndexOutOfBoundsException that was generated
        {
            System.out.println("ArrayIndexOutOfBounds exception is thrown. ArrayIndexOutOfBoundsExceptions are thrown \nby calling an item in a list that does not exist, which in this example is list[6]. \nAn exception would have also been generated if the number of list indeces to be cycled through was negative.");
        }
        
    }
    
}
