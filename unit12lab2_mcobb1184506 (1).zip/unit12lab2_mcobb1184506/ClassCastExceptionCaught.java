/*
 * This program throws and catches ClassCastExceptions.
 */
package classcastexceptioncaught;

/**
 *
 * @author Maya Cobb
 */
public class ClassCastExceptionCaught {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i = 8; //initialize and declare an integer value i
        
        try
        {      
            Object x = new Integer(0); //initialize and declare an integer value
            
        //ClassCastException thrown here - String is not a subclass of integer, so this conversion is not possible
        System.out.println((String)x);
        }
        
        catch (ClassCastException e)
        {
            System.out.println("ClassCastException thrown and caught. A ClassCastException is generated \nwhen code has attempted to cast an object to a subclass of which it is not \nan instance. In this example, String is not a subclass of integer, so this conversion \nis not possible and a ClassCastException is generated.");
        }
    }
    
}
