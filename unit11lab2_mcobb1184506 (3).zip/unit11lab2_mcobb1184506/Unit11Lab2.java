/*
 * This program removes duplicates from Integer ArrayLists
 */
package unit11lab2;

import java.util.ArrayList;

/**
 *
 * @author Maya Cobb
 */
public class Unit11Lab2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //create an Integer ArrayList
        ArrayList <Integer> List = new ArrayList<Integer>();
        
        //add elements to List
        List.add(5);
        List.add(32);
        List.add(1);
        List.add(5);
        List.add(57);
        List.add(1);
        
        System.out.println("list with duplicates: " + List);  //print List
        
        ArrayList <Integer> newList = removeDuplicates(List);  //remove the duplicates from List and store result in another Integer ArrayList
        
        System.out.println("list without duplicates " + newList);  //print the new ArrayList
        
    }
    
    public static ArrayList<Integer> removeDuplicates(ArrayList<Integer> list)
    {
        ArrayList <Integer> newList = new ArrayList<Integer>();  //create a new ArrayList in which to store non-duplicates of the indeces of the param list
        
        //add all unique elements of parameter list to newList
        for (Integer element:list)
        {
            if (!newList.contains(element))
                newList.add(element);
        }
        
        return newList;

    }
    
}
