/*
 * This program implements the Pet, Cat, and Dog classes to create a user interface
 * on which to set and display the name, weight, and age of the dog or cat object
 * as well as the song that that cat or dog object makes.
 */
package pettest;

/**
 *
 * @author Maya Cobb
 */
public class PetTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Pet pets [] = {new Cat(), new Dog(), new Dog(), new Cat()};
        
        for (int i = 0; i<= pets.length-1; i++)
        {
            pets[i].setPetInfo();
            
            System.out.println();
            
            System.out.println("name: " + pets[i].getPetName());
            System.out.println("weight: " + pets[i].getPetWeight());
            System.out.println("age: " + pets[i].getPetAge());
            System.out.println(pets[i].makeSound());
            
            System.out.println();
        }
    }
    
}
