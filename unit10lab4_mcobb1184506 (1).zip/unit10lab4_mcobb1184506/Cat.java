/*
 * This class defines attribute methods for the cat object/class.
 */
package createcats;

/**
 *
 * @author Maya Cobb
 */
public class Cat {
    
    private String breed;
    private int age;
    private double weight;
    private char sex;
    private String name;
    
    public Cat ()
    {
        breed = "tabby (default)";
        age = 0;
        weight = 00.00;
        sex = '?';
        name = "catName";
    }
    
    public String eat () //return eating sounds
    {
        return "Munch, munch, munch";
    }
    
    public String meow () //return meowing sounds
    {
        return "Meeeeeooww";
    }
    
    public void setBreed (String catBreed) //set cat breed
    {
        breed = catBreed;
    }
    
    public String getBreed () // retrieve cat weight
    {
        return breed;
    }
    
    public void setWeight (double catWeight) //set cat weight
    {
        weight = catWeight;
    }
    
    public double getWeight () //retrieve weight of cat
    {
        return weight;
    }
    
    public void setSexOfCat (char sexOfCat) //set sex of cat
    {
        sex = sexOfCat;
    }
    
    public char getSexOfCat ()  //retrieve sex of cat
    {
        return sex;
    }
    
    public void setName (String catName) //set name of cat
    {
        name = catName;
    }
    
    public String getName ()  //retrieve sex of cat
    {
        return name;
    }
    
    public void setAge (int catAge) //set age of cat
    {
        age = catAge;
    }
    
    public int getAge ()  //retrieve age of cat
    {
        return age;
    }
}
