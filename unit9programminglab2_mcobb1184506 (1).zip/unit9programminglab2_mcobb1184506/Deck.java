/*
 * This class represents a deck of playing cards. Note: pg 318 of the course textbook was used to make this class.
 */
package carddecktest;

import java.security.SecureRandom;

/**
 *
 * @author Maya Cobb
 */
public class Deck {
    
    private static final SecureRandom randomNumbers = new SecureRandom();
    private static final int numberOfCards = 52;
    
    private Card[] deck = new Card [numberOfCards];
    private int currentCard = 0;    
    
    public Deck ()
    {
        String [] faces = {"Ace", "Deuce", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King"};
        String [] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        
        for (int count = 0; count < deck.length; count++) {
            deck[count] = new Card(faces[count % 13], suits [count%4]);
        }
    }
    
    public String [] unshuffledDeck()
    {
        String [] deck = new String [numberOfCards];
        
        deck[0] = "Ace of Clubs";
        deck[1] = "Deuce of Clubs";
        deck[2] = "Three of Clubs";
        deck[3] = "Four of Clubs";
        deck[4] = "Five of Clubs";
        deck[5] = "Six of Clubs";
        deck[6] = "Seven of Clubs";
        deck[7] = "Eight of Clubs";
        deck[8] = "Nine of Clubs";
        deck[9] = "Ten of Clubs";
        deck[10] = "Jack of Clubs";
        deck[11] = "Queen of Clubs";
        deck[12] = "King of Clubs";
        
        deck[13] = "Ace of Diamonds";
        deck[14] = "Deuce of Diamonds";
        deck[15] = "Three of Diamonds";
        deck[16] = "Four of Diamonds";
        deck[17] = "Five of Diamonds";
        deck[18] = "Six of Diamonds";
        deck[19] = "Seven of Diamonds";
        deck[20] = "Eight of Diamonds";
        deck[21] = "Nine of Diamonds";
        deck[22] = "Ten of Diamonds";
        deck[23] = "Jack of Diamonds";
        deck[24] = "Queen of Diamonds";
        deck[25] = "King of Diamonds";
        
        deck[26] = "Ace of Hearts";
        deck[27] = "Deuce of Hearts";
        deck[28] = "Three of Hearts";
        deck[29] = "Four of Hearts";
        deck[30] = "Five of Hearts";
        deck[31] = "Six of Hearts";
        deck[32] = "Seven of Hearts";
        deck[33] = "Eight of Hearts";
        deck[34] = "Nine of Hearts";
        deck[35] = "Ten of Hearts";
        deck[36] = "Jack of Hearts";
        deck[37] = "Queen of Hearts";
        deck[38] = "King of Hearts";
        
        deck[39] = "Ace of Spades";
        deck[40] = "Deuce of Spades";
        deck[41] = "Three of Spades";
        deck[42] = "Four of Spades";
        deck[43] = "Five of Spades";
        deck[44] = "Six of Spades";
        deck[45] = "Seven of Spades";
        deck[46] = "Eight of Spades";
        deck[47] = "Nine of Spades";
        deck[48] = "Ten of Spades";
        deck[49] = "Jack of Spades";
        deck[50] = "Queen of Spades";
        deck[51] = "King of Spades";
        
        return deck;
    }
    
    public void shuffle ()
    {
        currentCard = 0;
        
        for (int first = 0; first < deck.length; first++) {
            int second = randomNumbers.nextInt(numberOfCards);
            
            Card temp = deck[first];
            deck[first] = deck[second];
            deck[second] = temp;
        }
    }  
    
    public Card dealCard () {
        if (currentCard < deck.length) {
            return deck[currentCard++];
        }
        else {
            return null;
        }
    }
 
}
