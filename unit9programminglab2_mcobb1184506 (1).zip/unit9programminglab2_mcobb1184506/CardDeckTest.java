/*
 * This class shuffles and deals the cards both shuffled and unshuffled.
 */
package carddecktest;

/**
 *
 * @author Maya Cobb
 */
public class CardDeckTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Deck deck = new Deck();
        
        System.out.println("UNSHUFFLED DECK:");
        
        for (int j = 0; j <= 50; j++) {
            System.out.print(deck.unshuffledDeck()[j] + ", ");
        }
        System.out.print(deck.unshuffledDeck()[51]);
        
        System.out.println("\n");
        
        System.out.println("SHUFFLED DECK:");
        
        deck.shuffle();
        
        for (int i = 0; i <= 51; i++) {
            System.out.print(deck.dealCard() + ", ");  
        }
        
        System.out.println("\n");
    }
    
}
