/*
 * This program uses a date and input class (to create dialog boxes) to ask the user for a day, month, and year, and then 
 * returns the date in a dialog box.
 */
package dateexercise;

import javax.swing.JOptionPane;

/**
 *
 * @author Maya Cobb
 */
public class DateExercise {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //create a new date object
        Date date = new Date ();
        
        //create a new input object so that we can call methods from the input class
        input input = new input();
        
        //enter day, month, and year in pop up box
        int month = input.getInt("Enter an integer month");
        
        int day = input.getInt("Enter an integer day");
        
        int year = input.getInt("Enter an integer year");
        
        //set day, month, and year
        date.setMonth(month);
        date.setDay(day);
        date.setYear(year);
        
        //produce error if input day is not a valid day of the specified month or is less than or equal to zero
        if (date.getMonth()==1 || date.getMonth() == 3 || date.getMonth() == 5 || date.getMonth() == 7 || date.getMonth() == 8 || date.getMonth() == 10 || date.getMonth() == 12)
        {
            if (date.getDay() > 31 || date.getDay() <= 0) {
                JOptionPane.showMessageDialog(null, "error: day input is not valid. restart program and try again.");
                throw new IllegalArgumentException ("day input is not valid");
            }
        }
        if (date.getMonth() == 4 || date.getMonth() == 6 || date.getMonth() == 9 || date.getMonth() == 11)
        {
            if (date.getDay() > 30 || date.getDay() <= 0) {
                JOptionPane.showMessageDialog(null, "error: day input is not valid. restart program and try again.");
                throw new IllegalArgumentException ("day input is not valid");
            }
        }
        if (date.getMonth() == 2 && date.getYear()%4 != 0)
        {
            if (date.getDay() > 28 || date.getDay() <= 0) {
                JOptionPane.showMessageDialog(null, "error: day input is not valid. restart program and try again.");
                throw new IllegalArgumentException ("day input is not valid");
            }
        }
        if ((date.getMonth() == 2 && date.getYear()%4 == 0))
        {
            if (date.getDay() > 29 || date.getDay() <= 0) {
                JOptionPane.showMessageDialog(null, "error: day input is not valid. restart program and try again.");
                throw new IllegalArgumentException ("day input is not valid");
            }
        }
        
        //produce error if input month is not 1-12
        if (date.getMonth() > 12 || date.getMonth() <= 0) {
            JOptionPane.showMessageDialog(null, "error: month input is not valid. restart program and try again.");
            throw new IllegalArgumentException ("month input is not valid");
        }
        
        //produce error if year value is negative
        if (date.getYear() < 0) {
            JOptionPane.showMessageDialog(null, "error: not a valid year, restart program and try again.");
            throw new IllegalArgumentException ("not a valid year");
        }    
        
        //show the date in a dialog box on the screen
        JOptionPane.showMessageDialog(null, "The date is " + date.getMonth()+"/"+date.getDay()+"/"+date.getYear());
    }
    
}
