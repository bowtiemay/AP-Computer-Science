/*
 * This class provides a few simple set and get methods for day, month, and year.
 */
package dateexercise;

/**
 *
 * @author Maya Cobb
 */
public class Date {
    private int day;
    private int month;
    private int year;    
    
    /**
    * precondition: day is within range for the specified month and not negative.
    * post conditions: this method will set the integer day to a valid value.
    * @param d is an integer
    */
    public void setDay (int d)
    {
        day = d;
    }
    
    /**
    * preconditions: month is in the range 1-12.
    * post conditions: this method will set the integer month to a valid value.
    * @param m is an integer
    */
    public void setMonth (int m)
    {
        month = m;
    }
    
    /**
    *preconditions: year is not negative, and if you want a four digit year to be outputted, the year inputted must be four digits.
    *post conditions: this method will output a valid year.
    * @param y is an integer
    */
    public void setYear (int y)
    {
        year = y;
    }
    
    /**
    *this method will return the integer 'day' value.
    *@return day value
    */
    public int getDay ()
    {
        return day;
    }
    
    /**
    *this method will return the integer 'month' value.
    *@return month value
    */
    public int getMonth ()
    {       
        return month;
    }
    
    /**
    *this method will return the integer 'year' value.
    *@return year value
    */
    public int getYear ()
    {
        return year;
    }
}
