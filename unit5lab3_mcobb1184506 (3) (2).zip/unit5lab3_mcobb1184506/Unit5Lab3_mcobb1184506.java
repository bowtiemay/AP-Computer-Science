/*
 * This program takes three values and outputs the maximum and minimum of those values
 */
package unit5lab3_mcobb1184506;

import java.util.Scanner;

/**
 *
 * @author marie
 */
public class Unit5Lab3_mcobb1184506 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner (System.in);
        
        double a;
        double b;
        double c;
        
        System.out.print("Enter a number: ");

        a = input.nextDouble();

        System.out.print("Enter a number: ");
        b = input.nextDouble();

        System.out.print("Enter a number: ");
        c = input.nextDouble();

        System.out.println("The minimum of the three values entered is " + min(a, b, c));
        System.out.println("The maximum of the three values entered is " + max(a, b, c));
        
        System.out.println("___________________________________________________________");
        
        double d;
        double e;
        double f;
        
        System.out.print("Enter a number: ");

        d = input.nextDouble();

        System.out.print("Enter a number: ");
        e = input.nextDouble();

        System.out.print("Enter a number: ");
        f = input.nextDouble();

        System.out.println("The minimum of the three values entered is " + min(d, e, f));
        System.out.println("The maximum of the three values entered is " + max(d, e, f));
        
        System.out.println("___________________________________________________________");
        
        double h;
        double i;
        double j;
        
        System.out.print("Enter a number: ");

        h = input.nextDouble();

        System.out.print("Enter a number: ");
        i = input.nextDouble();

        System.out.print("Enter a number: ");
        j = input.nextDouble();

        System.out.println("The minimum of the three values entered is " + min(h, i, j));
        System.out.println("The maximum of the three values entered is " + max(h, i, j));
        
    }
    
    private static double min (double a, double b, double c)
    {
        return Math.min(Math.min(a, b),c);
           
        }
    
    private static double max (double a, double b, double c)
    {
        return Math.max(Math.max(a, b),c);
           
        }
    }
    

