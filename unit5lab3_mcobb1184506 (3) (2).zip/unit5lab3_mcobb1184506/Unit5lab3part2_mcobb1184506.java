/*
 * This program takes four test scores from three different students and outputs the minimum, maximum, and average for each student.
 */

package unit5lab3part2_mcobb1184506;

import java.util.Scanner;

/**
 *
 * @author marie
 */
public class Unit5lab3part2_mcobb1184506 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner (System.in);
        
        System.out.println("______STUDENT 1_____________________________________________________");
        
        double a;
        double b;
        double c;
        double d;
        
        System.out.print("Enter the first score for student 1: ");

        a = input.nextDouble();

        System.out.print("Enter the second score for student 1: ");
        b = input.nextDouble();

        System.out.print("Enter the third score for student 1: ");
        c = input.nextDouble();
        
        System.out.print("Enter the fourth score for student 1: ");
        d = input.nextDouble();

        System.out.println("The lowest test score entered was " + min(a, b, c, d) + "%");
        System.out.println("The highest test score entered was " + max(a, b, c, d) + "%");
        System.out.println("The average of the test scores is " + avg(a, b, c, d) + "%");
        System.out.println("The letter grade for this student is a(n) " + letter_grade(a, b, c, d));
        
        System.out.println("______STUDENT 2_____________________________________________________");
        
        double e;
        double f;
        double g;
        double h;
        
        System.out.print("Enter the first test score for student 2: ");

        e = input.nextDouble();

        System.out.print("Enter the second test score for student 2: ");
        f = input.nextDouble();

        System.out.print("Enter the third test score for student 2: ");
        g = input.nextDouble();
        
        System.out.print("Enter the fourth test score for student 2: ");
        h = input.nextDouble();

        System.out.println("The lowest test score entered was " + min(e, f, g, h) + "%");
        System.out.println("The highest test score entered was " + max(e, f, g, h) + "%");
        System.out.println("The average of the test scores is " + avg(e, f, g, h) + "%");
        System.out.println("The letter grade for this student is a(n) " + letter_grade(e, f, g, h));
        
        System.out.println("______STUDENT 3_____________________________________________________");
        
        double i;
        double j;
        double k;
        double l;

        System.out.print("Enter the first test score for student 3: ");
        i = input.nextDouble();

        System.out.print("Enter the second test score for student 3: ");
        j = input.nextDouble();
        
        System.out.print("Enter the third test score for student 3: ");
        k = input.nextDouble();
        
        System.out.print("Enter the fourth test score for student 3: ");
        l = input.nextDouble();

        System.out.println("The lowest test score entered was " + min(i, j, k, l) + "%");
        System.out.println("The highest test score entered was " + max(i, j, k, l) + "%");
        System.out.println("The average of the test scores is " + avg(i, j, k, l) + "%");
        System.out.println("The letter grade for this student is a(n) " + letter_grade(i, j, k, l));
        
    }
    
    private static double min (double a, double b, double c, double d)
    {
        return Math.min(Math.min(a, b), Math.min(c, d) );
           
        }
    
    private static double max (double a, double b, double c, double d)
    {
        return Math.max(Math.max(a, b), Math.max(c, d) );
           
        }
    
    private static double avg (double a, double b, double c, double d)
    {
        double average = (a+b+c+d)/4;
        double one_decimal = Math.floor(average * 10 + 0.5) / 10;
        return one_decimal;
    }
    
    private static String letter_grade (double a, double b, double c, double d)
    {
        int average = (int) (a+b+c+d)/4;
        
        if (100 <= average) {
            return "A+";
        }
        else if (average >= 90 && average <=100) {
            return "A";
        }
        else if (average >= 80 && average <= 89) {
            return "B";
        }
        else if (average >= 70 && average <= 79) {
            return "C";
        }
        else if (average >= 65 && average <= 69) {
            return "D";
        }
        else {
            return "F";
        }
    }
    
}

    

        



    
    

       