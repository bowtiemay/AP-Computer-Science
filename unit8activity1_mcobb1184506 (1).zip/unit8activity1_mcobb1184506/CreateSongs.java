/*
 * This program demos ways in which the methods of the song class can be used to 
 * show attributes of an individual song in an organized fashion.
 */
package createsongs;

/**
 *
 * @author Maya Cobb
 */
public class CreateSongs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Song song1 = new Song();
        
        System.out.println("SONG 1");
        
        song1.setName("Ophelia");
        System.out.println("name: " + song1.getName());
        
        song1.setRecordingArtist("The Lumineers");
        System.out.println("recording artist: " + song1.getRecordingArtist());
        
        song1.setCategory("alternative/indie");
        System.out.println("category/genre: " + song1.getCategory());
        
        song1.setPrice(3.99);
        System.out.println("price: " + song1.getPrice());
        
        System.out.println();
    }
    
}
