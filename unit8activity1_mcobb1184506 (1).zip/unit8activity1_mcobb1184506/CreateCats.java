/*
 * This program makes two cat objects and invokes the methods of those cat objects
 * from the cat class. The output will show the original attributes of cat 1 and 
 * cat 2, and then will show the changed values of some of the attributes associated 
 * with each cat object as well as the original attributes. Throughout the program, 
 * the meow() and eat() behaviors defined in the cat class are also called.
 */
package createcats;

/**
 *
 * @author Maya Cobb
 */
public class CreateCats {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // create two cat objects
        Cat catOne = new Cat();
        Cat catTwo = new Cat();
        
        //make the cats eat
        System.out.println("cat 1 says " + catOne.eat()); 
        
        System.out.println("cat 2 says " + catTwo.eat()); 
        
        System.out.println();
        
        // make the cats meow
        System.out.println("cat 1 says " + catOne.meow()); 
        
        System.out.println("cat 2 says " + catTwo.meow()); 
        
        System.out.println();
        
        //CAT 1
        System.out.println("CAT 1");
        
        catOne.setName("Marie");
        System.out.println("name: " + catOne.getName());
        
        catOne.setBreed("tabby");
        System.out.println("breed: " + catOne.getBreed());
        
        catOne.setWeight(12.01);
        System.out.println("weight = " + catOne.getWeight() + " lbs");
        
        catOne.setSexOfCat('f');
        System.out.println("sex = " + catOne.getSexOfCat());
        
        catOne.setAge(8);
        System.out.println("age = " + catOne.getAge() + " years");
        
        System.out.println();
        
        //CAT 2
        System.out.println("CAT 2");
        
        catTwo.setName("Dante");
        System.out.println("name: " + catTwo.getName());
        
        catTwo.setBreed("domestic medium hair");
        System.out.println("breed: " + catTwo.getBreed());
        
        catTwo.setWeight(16.00);
        System.out.println("weight = " + catTwo.getWeight() + " lbs");
        
        catTwo.setSexOfCat('m');
        System.out.println("sex = " + catTwo.getSexOfCat());
        
        catTwo.setAge(9);
        System.out.println("age = " + catTwo.getAge() + " years");
        
        System.out.println();
        
        //CAT 1 NAME AND AGE CHANGE
        System.out.println("CAT 1 (changed name and age)");
        
        catOne.setName("Alice");
        System.out.println("name: " + catOne.getName());
        
        catOne.setBreed("tabby");
        System.out.println("breed: " + catOne.getBreed());
        
        catOne.setWeight(12.01);
        System.out.println("weight = " + catOne.getWeight() + " lbs");
        
        catOne.setSexOfCat('f');
        System.out.println("sex = " + catOne.getSexOfCat());
        
        catOne.setAge(4);
        System.out.println("age = " + catOne.getAge() + " years");
        
        System.out.println();
        
        //CAT 2 AGE AND WEIGHT CHANGE, INVOKE MEOW() METHOD
        System.out.println("CAT 2 (changed age and weight, meow method)");
        
        catTwo.setName("Dante");
        System.out.println("name: " + catTwo.getName());
        
        catTwo.setBreed("domestic medium hair");
        System.out.println("breed: " + catTwo.getBreed());
        
        catTwo.setWeight(14.00);
        System.out.println("weight = " + catTwo.getWeight() + " lbs");
        
        catTwo.setSexOfCat('m');
        System.out.println("sex = " + catTwo.getSexOfCat());
        
        catTwo.setAge(12);
        System.out.println("age = " + catTwo.getAge() + " years");
        
        System.out.println("cat 2 says " + catTwo.meow()); 
        
        System.out.println();
    }
    
    
    
}
