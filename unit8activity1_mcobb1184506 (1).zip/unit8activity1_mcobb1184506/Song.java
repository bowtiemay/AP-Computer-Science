/*
 * This class defines attribute methods to be utilized by song objects.
 */
package createsongs;

/**
 *
 * @author Maya Cobb
 */
public class Song {
    
    private String name;
    private String recordingArtist;
    private String category;
    private double price;
    
    
    public void setName (String songName) //set song name
    {
        name = songName;
    }
    
    public String getName () // retrieve song name
    {
        return name;
    }
    
    public void setRecordingArtist (String artist) // set artist
    {
        recordingArtist = artist;
    }
    
    public String getRecordingArtist () // retrieve artist
    {
        return recordingArtist;
    }
    
    public void setCategory (String songCategory) //set category
    {
        category = songCategory;
    }
    
    public String getCategory () //retrieve category
    {
        return category;
    }
    
    public void setPrice (double songPrice) //set price
    {
        price = songPrice;
    }
    
    public double getPrice () //get price
    {
        return price;
    }
    
}
