/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unit4activity1_mcobb1184506;

/**
 *
 * @author marie
 */
import java.util.Scanner;

public class Unit4activity1_mcobb1184506 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.print("How many questions would you like to generate? ");
        Scanner input = new Scanner (System.in);
        int question_number = input.nextInt();
        System.out.println();
                    
        float number_correct = (float) 0.00;
        float total_questions = question_number;
        
        long startTime = System.currentTimeMillis();
        
        while (question_number > 0)
        {
            // Generate two random numbers that will be multiplied
            int number1 = (int) (Math.random() * 10);
            int number2 = (int) (Math.random() * 10);

            //Prompt user to input answer
            System.out.print("What is " + number1 + " * " + number2 + "? ");
            //Scanner input = new Scanner (System.in);
            int answer2 = input.nextInt();
            int correct_answer = number1 * number2;

            //Grade the answer
            if (correct_answer==answer2)
            {
                System.out.println("Congratulations...you are correct!\n");
                number_correct++;
            }
            else {
                System.out.println("You are wrong. The correct answer is " + correct_answer + ".\n");
            }
            
            question_number--;
            
       }
       
        long stopTime = System.currentTimeMillis();
        long elapsedTime = (stopTime - startTime) / 1000;
        
        float score = (number_correct / total_questions) * 100;
        //int score = (int) s*100;
        
        System.out.println("Quiz complete. Your score is " + score + "%. You took "+  elapsedTime + " second(s) to complete this quiz.\n");
        
        }
}

