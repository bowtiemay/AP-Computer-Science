/*
 * This program tests the methods from the ArrayTools class.
 */
package unit6lab3;

/**
 *
 * @author Maya Cobb
 */
public class Unit6lab3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        char char_list[] = {'Q', 'C', 'A', 'X', 'W', 'P'};
        char char_list2[] = {'Q', 'C', 'A', 'X', 'W', 'P'};
        
        System.out.println("the two character lists are equal: " + ArrayTools.equals(char_list, char_list2));
        System.out.println("what is the index location of the letter A in the (unsorted) first character list?: " + ArrayTools.find(char_list, 'A'));
        ArrayTools.sort(char_list);
        System.out.println("sort the character list in increasing order: " + char_list[0]+", "+char_list[1]+", "+char_list[2]+", "+char_list[3]+", "+char_list[4]+", "+char_list[5]);
            
        System.out.println();
        
        int int_list[] = {34, 23, 654, 234, 45, 65, 43, 765, 3};
        int int_list2[] = {12, 34, 75, 99, 273, 32, 345, 7, 65};
        System.out.println("the two integer lists are equal: " + ArrayTools.equals(int_list, int_list2));
        System.out.println("what is the index location of the integer 23 in the (unsorted) first integer list?: " + ArrayTools.find(int_list, 23));
        ArrayTools.sort(int_list);
        System.out.println("sort the integer list in increasing order: " + int_list[0]+", "+int_list[1]+", "+int_list[2]+", "+int_list[3]+", "+int_list[4]+", "+int_list[5]);
       
        System.out.println();
        
        double double_list[] = {54.34, 23.2, 3456.45, 767.45, 6.23, 18.12};
        double double_list2[] = {234.32, 435.54, 43.56, 23.99, 56.44, 92.18};
        System.out.println("the two double lists are equal: " + ArrayTools.equals(double_list, double_list2));
        System.out.println("what is the index location of the double 54.34 in the (unsorted) first double list?: " + ArrayTools.find(double_list, 54.34));
        ArrayTools.sort(double_list);
        System.out.println("sort the double list in increasing order: " + double_list[0]+", "+double_list[1]+", "+double_list[2]+", "+double_list[3]+", "+double_list[4]+", "+double_list[5]);
        
    }
    
}

    

