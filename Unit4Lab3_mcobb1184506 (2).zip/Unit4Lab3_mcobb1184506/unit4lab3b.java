/*
 * This program asks the user to input 10 numbers and uses a for loop to find
* The greatest and smallest of those numbers.
 */
package unit4lab3b;

import java.util.Scanner;

/**
 *
 * @maya
 */
public class unit4lab3b {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
        Scanner input = new Scanner (System.in);
        
        int counter;
        int largest = -1000000000;
        int smallest = 1000000000;
        int number = 0;
        
        for(counter = 1; counter <= 10; counter++)
        {
            System.out.print("Enter an integer: ");
            number = input.nextInt();
            
            if (number > largest)
            {
                largest = number;
            }
            
            
            if (number < smallest)
            {
                smallest = number;
            }
            }
            
            number++;
            
            System.out.println("The largest number in the given set is " + largest);
            System.out.println("The smallest number in the given set is " + smallest);
            
        }
        
           
    }
   
