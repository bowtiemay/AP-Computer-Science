/*
 * This program asks the user to input 10 numbers and uses a while loop to find
* The greatest and smallest of those numbers.
 */
package unit4lab3a_;

import java.util.Scanner;

/**
 *
 * @maya
 */
public class Unit4Lab3A_ {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
        Scanner input = new Scanner (System.in);
        
        int counter = 1;
        int largest = -1000000000;
        int smallest = 1000000000;
        int number = 0;
        
        while(counter <= 10)
        {
            System.out.print("Enter an integer: ");
            number = input.nextInt();
            counter++;
            
            if (number > largest)
            {
                largest = number;
            }
            
            
            if (number < smallest)
            {
                smallest = number;
            }
            }
            
            number++;
            
            System.out.println("The largest number in the given set is " + largest);
            System.out.println("The smallest number in the given set is " + smallest);
            
        }
        
           
    }
   
