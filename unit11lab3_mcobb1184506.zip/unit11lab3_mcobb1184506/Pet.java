/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pettest;

import java.util.Scanner;

/**
 *
 * @author marie
 */
public class Pet {
    
    private String name;
    private double weight;
    private int age;
     
    public void setPetInfo ()
    {
        Scanner input = new Scanner (System.in);
        System.out.print("What is the name of your pet?: ");
        name = input.nextLine();
        System.out.print("What is the weight of your pet?: ");
        weight = input.nextDouble();
        System.out.print("What is the age of your pet?: ");
        age = input.nextInt();
    }
    
    public String getPetName()
    {
        return name;
    }
    
    public double getPetWeight()
    {
        return weight;
    }
    
    public double getPetAge()
    {
        return age;
    }
    
    public String makeSound()
    {
        return "";
    }
}
