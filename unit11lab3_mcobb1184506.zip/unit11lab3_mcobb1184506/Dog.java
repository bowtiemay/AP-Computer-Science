/*
 * This program defines methods for a Dog object. This class extends the Pet class.
 */
package pettest;

/**
 *
 * @author Maya Cobb
 */
public class Dog extends Pet {
    
    //method to have the dog make a sound
    public String makeSound()
    {
        return "bow wow";
    }
}
