/*
 * This program implements the Pet, Cat, and Dog classes to create a user interface
 * on which to set and display the name, weight, and age of the dog or cat object
 * as well as the song that that cat or dog object makes. This implementation stores
 * the pet objects in an ArrayList instead of an array.
 */
package pettest;

import java.util.ArrayList;

/**
 *
 * @author Maya Cobb
 */
public class PetTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //make an ArrayList of pet objects
        ArrayList <Pet> pets = new ArrayList<Pet>();
        pets.add(new Cat());  //add a cat to the arraylist of pet objects
        pets.add(new Dog());  //add a dog to the arraylist of pet objects
        pets.add(new Cat());  //add another cat to the arraylist of pet objects
        
        //Pet pets [] = {new Cat(), new Dog(), new Dog(), new Cat()};
        
        // iterate through the pets arraylist
        for (int i = 0; i<= pets.size()-1; i++)
        {
            pets.get(i).setPetInfo(); //call the pets setPetInfo method to have the user set the pet info
            
            System.out.println();
            
            //print the pet information
            System.out.println("name: " + pets.get(i).getPetName());
            System.out.println("weight: " + pets.get(i).getPetWeight());
            System.out.println("age: " + pets.get(i).getPetAge());
            System.out.println(pets.get(i).makeSound());
            
            System.out.println();
            
        }
        
        System.out.println("AVERAGE OF ALL OF THE PET AGES: " + calculateAverage(pets));
        
        System.out.println();
        
    }
    
    //calculate the average of the ages of the inputted pets
    public static double calculateAverage( ArrayList<Pet> list )
    {
        double total = 0; //total variable to keep track of the total of all of the pet ages
        double average;  //average variable
        
        //iterate through the list of pets and add each pet age to the total of the pet ages
        for (int i = 0; i < list.size(); i++)  
        {
            total = total + list.get(i).getPetAge();
        }
        
        //divide the total of the pet ages by the number of items in the Pet list to get the average of the pet ages
        average = total/list.size();
       
        return average;
    }
    
}
