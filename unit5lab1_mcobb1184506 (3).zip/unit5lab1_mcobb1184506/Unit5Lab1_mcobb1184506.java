/*
 * This program prompts the user to choose a financial function to use as well as values needed to use that financial 
 * function, then outputs the result of the given financial function.
 */
package unit5lab1_mcobb1184506;

import java.util.Scanner;

/**
 *
 * @author marie
 */
public class Unit5Lab1_mcobb1184506 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner (System.in);
        
        System.out.println("What financial function would you like to use? (future value of a single sum, present value of a single sum, future value of an annuity): ");
        String what_function = input.nextLine();
        
        String functionfs = "future value of a single sum";
        String functionps = "present value of a single sum";
        String functionfa = "future value of an annuity";
        
        if (what_function.equals(functionfs))
        {
            System.out.print("Enter the amt of dollars deposited in a savings account: $");
            double dollars_deposited = input.nextDouble();
            System.out.print("Enter the number of years that that amount is in the account: ");
            double years_after_deposit = input.nextDouble();
            System.out.print("Enter the interest rate in decimal form: ");
            double interest = input.nextDouble();
            System.out.println("$"+ future_value_single_sum(interest, dollars_deposited, years_after_deposit) +" would be in the account after "+years_after_deposit+" years.");
        }
        else if (what_function.equals(functionps))
        {
            System.out.print("Enter how much you would like to have in the account: $");
            double ideal_dollars = input.nextDouble();
            System.out.print("Enter the the number of years in which you would like to have this amount: ");
            double number_years = input.nextDouble();
            System.out.print("Enter the interest rate in decimal form: ");
            double interest2 = input.nextDouble();
            System.out.println("You should deposit $"+present_value_single_sum(ideal_dollars, number_years, interest2)+" in order to have $"+ideal_dollars+ " in "+number_years+ " years.");
            
        }
        else if (what_function.equals(functionfa))
        {
            System.out.print("Enter the amount of money you deposit into a savings account each month: $");
            double dollars_deposited_monthly = input.nextDouble();
            System.out.print("Enter the amount of years you deposit that amount of money monthly for: ");
            double years_deposited = input.nextDouble();
            System.out.print("Enter the interest rate in decimal form: ");
            double interest3 = input.nextDouble();
            System.out.println("$"+future_value_annuity(dollars_deposited_monthly, years_deposited, interest3)+" would be in the account after depositing a monthly amount of $"+dollars_deposited_monthly+" for "+years_deposited+" years");
        }
        else 
            System.out.println("That is not a valid function. Check to make sure that your function is exactly the same as the ones outlined.");
 
    }
    
    private static double future_value_single_sum (double interest, double dollars_deposited, double years_after_deposit) {
        double future_value = dollars_deposited * Math.pow((1 + interest), years_after_deposit);
        double two_decimal = Math.floor(future_value * 100 + 0.5) / 100;
        return two_decimal;
}
    private static double present_value_single_sum (double ideal_dollars, double number_years, double interest2)
    {
        double value_to_deposit = ideal_dollars / Math.pow((1+interest2), number_years);
        double two_decimal = Math.floor(value_to_deposit * 100 + 0.5) / 100;
        return two_decimal;
    }
    private static double future_value_annuity (double dollars_deposited_monthly, double years_deposited, double interest3)
    {
        double total_dollars = dollars_deposited_monthly * (Math.pow((1+interest3), years_deposited)-1)/interest3;
        double two_decimal = Math.floor(total_dollars * 100 + 0.5) / 100;
        return two_decimal;
    }
}
