/*
 * This program takes a time and uses time class methods to convert the time into a  *universal string and a string. Note: first part of code copied from Java How to Program Late Objects Edition pg.348-350
 */
package testtime2;

/**
 *
 * @author Maya Cobb
 */
public class TestTime2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Here is the result of the original program that stored hours, minutes, and seconds internally: ");
        
        Time2 time = new Time2();
        time.setTime(22, 22, 3);
        
        System.out.println(time.toUniversalString());
        System.out.println(time.toString());
        
        System.out.println();
        
        System.out.println("Here is the result of the new methods that stored cumulative seconds internally: ");
        
        Time2 time2 = new Time2();
        time2.setTime(22, 22, 3);
        
        System.out.println(time2.ToUniversalString());
        System.out.println(time2.ToString());
        
        System.out.println();
        
        System.out.println("If you look at the first time result and the second time result, there is no difference, even though the second stored cumulative seconds.");
    }
    
}
