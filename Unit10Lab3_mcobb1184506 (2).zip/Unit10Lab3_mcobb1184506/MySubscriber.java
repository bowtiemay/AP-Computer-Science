/*
 * This class extendst the Subscriber class
 */
package testpattern;

/**
 *
 * @author marie
 */
public class MySubscriber extends Subscriber {
    
    public void update (int x)
    {
        System.out.println("Subscriber " + x + " has been notified");
    }
}
