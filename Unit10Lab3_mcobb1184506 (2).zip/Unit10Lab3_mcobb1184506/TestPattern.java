/*
 * This program implements the various publisher and subscriber methods.
 */
package testpattern;

/**
 *
 * @author marie
 */
public class TestPattern {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Create Publisher And Subsciber objects
        MyPublisher aPublisher = new MyPublisher(3);
        
        MySubscriber aSubscriber1 = new MySubscriber();
        MySubscriber aSubscriber2 = new MySubscriber();
        MySubscriber aSubscriber3 = new MySubscriber();
        
        //Register a Subscriber
        aPublisher.register(aSubscriber1);
        aPublisher.register(aSubscriber2);
        aPublisher.register(aSubscriber3);
        
        //Increment Publisher object to cause state changes
        aPublisher.increment();
        aPublisher.increment();
        aPublisher.increment();
        
        System.out.println();
    }
    
}
