/*
 * This class provides various methods for Publisher objects.
 */
package testpattern;

/**
 *
 * @author marie
 */
public class Publisher {
    
    private Subscriber [] subscriberList;  //an array storing subscribers
    private int maximumSubscribers;        //maximum number of subscribers
    private int nextIndex;                 //array index of next subscriber
    
    public Publisher ( int max )
    {
        //Initialize attributes and create subscriber array
        maximumSubscribers = max;
        subscriberList = new Subscriber [maximumSubscribers];
        nextIndex = 0;
    }
    
    public void register (Subscriber s)
    {
        //Register a subscriber unless the subscriber array is full
        if (nextIndex < maximumSubscribers)
            subscriberList[nextIndex++] = s;
        else
            System.out.println("ERROR: Subscriber List is full");
    }
    
    public void notifySubscribers()
    {
        //iterate through the subscriber array and invoe the update() method
        for (int i = 0; i < nextIndex; i++)
            subscriberList[i].update(i+1);
    }
}
