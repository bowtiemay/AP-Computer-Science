/*
 * This class provides a method for Subscriber objects.
 */
package testpattern;

/**
 *
 * @author marie
 */
public class Subscriber {
    
    public void update(int x)
    {
        
    }
}
